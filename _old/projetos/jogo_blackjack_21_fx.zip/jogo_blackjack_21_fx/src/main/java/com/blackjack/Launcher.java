package com.blackjack;

public class Launcher {
    public static void main(String[] args) {
        BlackjackApp.main(args);
    }
}